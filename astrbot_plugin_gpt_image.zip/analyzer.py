"""LLM：仅审核 + 选择分辨率/画幅。不改写用户生图 prompt。"""

from __future__ import annotations

import json
import re
import unicodedata
from dataclasses import dataclass
from typing import Any

from astrbot.api import logger

from .constants import (
    ANALYZE_SYSTEM_PROMPT,
    GPT_IMAGE_RATIOS,
    RESOLUTIONS,
    SENSITIVE_KEYWORDS,
    parse_ratio_token,
    parse_resolution_token,
)


@dataclass
class AnalyzeResult:
    """LLM/规则分析结果。不含生图 prompt——prompt 始终是用户原文。"""

    allowed: bool
    reason: str = ""
    resolution: str = "2k"
    aspect_ratio: str = "1:1"
    source: str = "default"  # default | keyword | llm | manual

    def to_meta(self) -> str:
        status = "通过" if self.allowed else "拒绝"
        return (
            f"审核={status} | {self.resolution.upper()} {self.aspect_ratio} | 来源={self.source}"
            + (f" | {self.reason}" if self.reason and not self.allowed else "")
        )


_JSON_BLOCK_RE = re.compile(r"\{[\s\S]*\}")


def _normalize_for_keyword(text: str) -> str:
    """
    规范化文本以便关键词匹配，降低拆字/插符号绕过：
    - NFKC 全半角统一
    - 小写
    - 去零宽字符
    - 去掉空白与常见分隔符（空格、点、*、_、-、· 等）
    """
    s = unicodedata.normalize("NFKC", text or "")
    s = s.lower()
    s = re.sub(r"[\u200b-\u200f\u202a-\u202e\u2060-\u206f\ufeff\u00ad]", "", s)
    # 去掉空白与插在汉字间的常见干扰符
    s = re.sub(r"[\s\t\r\n\.\,\,;:!\?\!\?\*\_\-\—\–·•、，。；：！？/\\|~`@#$%^&+=()\[\]{}<>\"']+", "", s)
    return s


def keyword_audit(prompt: str) -> AnalyzeResult | None:
    """政治类关键词快速拦截。命中返回拒绝结果，否则 None。"""
    compact = _normalize_for_keyword(prompt)
    if not compact:
        return None
    for kw in SENSITIVE_KEYWORDS:
        k = _normalize_for_keyword(kw)
        if not k:
            continue
        if k in compact:
            return AnalyzeResult(
                allowed=False,
                reason="触发政治敏感词预检",
                source="keyword",
            )
    return None


def heuristic_size(prompt: str, default_res: str, default_ratio: str) -> AnalyzeResult:
    """无 LLM 时的启发式分辨率/比例。只读 prompt 语义，不改写文本。"""
    p = (prompt or "").lower()
    res = default_res if default_res in RESOLUTIONS else "2k"
    ratio = default_ratio if default_ratio in GPT_IMAGE_RATIOS else "1:1"

    if any(x in p for x in ("4k", "超清", "海报", "印刷", "壁纸", "wallpaper", "海报级", "高清大图")):
        res = "4k"
    elif any(x in p for x in ("图标", "icon", "emoji", "头像小", "草稿", "sketch")):
        res = "1k"

    if any(x in p for x in ("竖图", "竖屏", "手机壁纸", "portrait", "9:16", "9x16")):
        ratio = "9:16"
    elif any(x in p for x in ("横图", "横屏", "宽屏", "landscape", "16:9", "16x9", "电影")):
        ratio = "16:9"
    elif any(x in p for x in ("超宽", "21:9", "21x9", "带鱼")):
        ratio = "21:9"
    elif any(x in p for x in ("正方形", "头像", "1:1", "1x1", "square")):
        ratio = "1:1"
    elif any(x in p for x in ("3:2", "3x2")):
        ratio = "3:2"
    elif any(x in p for x in ("2:3", "2x3")):
        ratio = "2:3"
    elif any(x in p for x in ("4:3", "4x3")):
        ratio = "4:3"
    elif any(x in p for x in ("3:4", "3x4")):
        ratio = "3:4"

    return AnalyzeResult(
        allowed=True,
        resolution=res,
        aspect_ratio=ratio,
        source="default",
    )


def parse_llm_json(text: str) -> dict[str, Any] | None:
    if not text:
        return None
    raw = text.strip()
    if raw.startswith("```"):
        raw = re.sub(r"^```(?:json)?\s*", "", raw)
        raw = re.sub(r"\s*```$", "", raw)
    try:
        return json.loads(raw)
    except Exception:
        pass
    m = _JSON_BLOCK_RE.search(text)
    if not m:
        return None
    try:
        return json.loads(m.group(0))
    except Exception:
        return None


def normalize_analyze_dict(
    data: dict[str, Any],
    *,
    default_res: str,
    default_ratio: str,
    strict: bool,
    audit_enabled: bool = True,
) -> AnalyzeResult:
    """只解析审核结果与模型参数；忽略任何 cleaned_prompt / rewritten 字段。

    audit_enabled=True 且缺 allowed 字段：视为拒绝（不默认放行）。
    audit_enabled=False：allowed 始终视为 True。
    """
    if "allowed" in data:
        allowed_raw = data.get("allowed")
        if isinstance(allowed_raw, str):
            allowed = allowed_raw.strip().lower() in {"1", "true", "yes", "y", "通过", "允许"}
        else:
            allowed = bool(allowed_raw)
    else:
        # 缺字段：审核开启时安全默认为拒绝
        allowed = not audit_enabled

    reason = str(data.get("reason") or "").strip()
    res = str(data.get("resolution") or default_res).strip().lower()
    if res not in RESOLUTIONS:
        res = parse_resolution_token(res) or (
            default_res if default_res in RESOLUTIONS else "2k"
        )

    ratio_raw = str(data.get("aspect_ratio") or default_ratio).strip()
    ratio = parse_ratio_token(ratio_raw) or (
        default_ratio if default_ratio in GPT_IMAGE_RATIOS else "1:1"
    )

    if not allowed and not reason:
        reason = "内容未通过安全审核"

    # 仅当模型显式标出高政治风险时才加拒；不因 medium/娱乐向 uncertain 误杀
    if strict:
        flag = str(data.get("risk") or data.get("risk_level") or "").lower()
        if flag in {"high", "political", "ban", "block"}:
            allowed = False
            reason = reason or "判定存在政治合规风险"

    return AnalyzeResult(
        allowed=allowed,
        reason=reason,
        resolution=res,
        aspect_ratio=ratio,
        source="llm",
    )


async def llm_analyze(
    context,
    *,
    prompt: str,
    umo: str | None,
    default_res: str,
    default_ratio: str,
    enable_audit: bool,
    strict: bool,
    timeout: float = 45.0,
    system_prompt: str | None = None,
    enable_keyword_filter: bool = True,
    provider_id: str | None = None,
) -> AnalyzeResult:
    """
    使用当前对话模型：审核（可选）+ 选择 resolution/aspect_ratio。

    重要：本函数绝不改写用户 prompt；生图文本由调用方原样传入 adobe2api。

    provider_id 非空时优先按 ID 取指定的 LLM 提供商（例如专门配置的快速审核模型），
    获取失败则回退到当前会话正在使用的模型。
    """
    # 关键词预检始终优先（政治硬拦），与 LLM 是否开启无关时仍建议开启
    if enable_audit and enable_keyword_filter:
        hit = keyword_audit(prompt)
        if hit:
            return hit

    fallback = heuristic_size(prompt, default_res, default_ratio)

    provider = None
    pid = (provider_id or "").strip()
    if pid:
        try:
            provider = context.get_provider_by_id(provider_id=pid)
            if provider is None:
                logger.warning(
                    f"[gpt_image][审核] 指定的 audit_provider_id={pid!r} 未找到，回退当前会话模型"
                )
        except TypeError:
            # 兼容旧版本按位置参数
            try:
                provider = context.get_provider_by_id(pid)
            except Exception as e:
                logger.warning(
                    f"[gpt_image][审核] 按 ID 获取审核 provider 失败 id={pid!r}: {e}"
                )
                provider = None
        except Exception as e:
            logger.warning(
                f"[gpt_image][审核] 按 ID 获取审核 provider 失败 id={pid!r}: {e}"
            )
            provider = None

    if provider is None:
        try:
            provider = context.get_using_provider(umo) if umo else context.get_using_provider()
        except TypeError:
            try:
                provider = context.get_using_provider()
            except Exception:
                provider = None
        except Exception as e:
            logger.warning(f"获取 LLM Provider 失败: {e}")

    if provider is None:
        logger.warning("无可用 LLM Provider，使用启发式尺寸选择")
        # 审核开启但无 LLM：关键词已过则放行选尺寸（关键词是政治硬拦）
        return fallback

    sys_prompt = (system_prompt or "").strip() or ANALYZE_SYSTEM_PROMPT

    user_msg = (
        "请根据系统规则：1) 政治安全审核（若开启）2) 选择分辨率与画幅。\n"
        "重点拦截政治/分裂/暴恐/邪教；娱乐明星与粉丝向创作应放行。\n"
        "不要改写、翻译或润色用户描述；不要输出生图用的 prompt 正文。\n"
        "只输出 JSON 字段：allowed, reason, resolution, aspect_ratio。\n"
        f"默认分辨率: {default_res}\n"
        f"默认比例: {default_ratio}\n"
        f"审核开关: {'on' if enable_audit else 'off（allowed 必须为 true，仅选尺寸）'}\n"
        f"严格模式: {strict}（仅对政治擦边从严，不要对娱乐内容从严）\n\n"
        f"用户原文（仅供你理解意图，系统会原样用于生图）:\n{prompt}"
    )

    try:
        resp = await provider.text_chat(
            prompt=user_msg,
            session_id=None,
            image_urls=[],
            func_tool=None,
            contexts=[],
            system_prompt=sys_prompt,
        )
        text = ""
        if resp is None:
            text = ""
        elif hasattr(resp, "completion_text"):
            text = resp.completion_text or ""
        elif isinstance(resp, str):
            text = resp
        else:
            text = str(getattr(resp, "result", "") or getattr(resp, "text", "") or resp)

        data = parse_llm_json(text)
        if not data:
            logger.warning(f"LLM 返回无法解析为 JSON: {text[:200]}")
            # LLM 失败时再跑一遍关键词；政治词已拦，其余放行选尺寸
            if enable_audit and enable_keyword_filter:
                hit = keyword_audit(prompt)
                if hit:
                    return hit
            return fallback

        result = normalize_analyze_dict(
            data,
            default_res=default_res,
            default_ratio=default_ratio,
            # 严格模式只强化政治判断；normalize 里 risk 字段仍可触发
            strict=strict and enable_audit,
            audit_enabled=enable_audit,
        )
        if not enable_audit:
            result.allowed = True
            result.reason = ""
        # 二次关键词兜底：防止 LLM 误放行政治词
        if enable_audit and enable_keyword_filter and result.allowed:
            hit = keyword_audit(prompt)
            if hit:
                return hit
        return result
    except Exception as e:
        logger.error(f"LLM 分析失败，回退启发式: {e}")
        if enable_audit and enable_keyword_filter:
            hit = keyword_audit(prompt)
            if hit:
                return hit
        return fallback


def parse_user_overrides(text: str) -> tuple[str, dict[str, Any]]:
    """
    从用户输入拆出可选参数，返回 (用户生图原文, overrides)。

    仅剥离 --ratio / 比例: 与 --no-audit / --no-auto 等控制参数；
    描述正文保持用户原语言原样。分辨率由插件配置统一决定，不接受用户覆盖。
    """
    overrides: dict[str, Any] = {}
    remaining = text or ""

    patterns = [
        (r"(?:--ratio|--aspect|-r)\s+([^\s]+)", "ratio"),
        (r"(?:比例[:：])\s*([^\s]+)", "ratio"),
    ]

    for pat, key in patterns:

        def _sub(m, _key=key):
            overrides[_key] = m.group(1).strip()
            return " "

        remaining = re.sub(pat, _sub, remaining, flags=re.IGNORECASE)

    if re.search(r"(?:--no-audit)\b", remaining, flags=re.IGNORECASE):
        overrides["no_audit"] = True
        remaining = re.sub(r"(?:--no-audit)\b", " ", remaining, flags=re.IGNORECASE)

    if re.search(r"(?:--no-auto)\b", remaining, flags=re.IGNORECASE):
        overrides["no_auto"] = True
        remaining = re.sub(r"(?:--no-auto)\b", " ", remaining, flags=re.IGNORECASE)

    remaining = re.sub(r"\s+", " ", remaining).strip()
    return remaining, overrides
